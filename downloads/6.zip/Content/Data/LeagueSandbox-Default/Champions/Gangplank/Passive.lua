Vector2 = require 'Vector2' -- include 2d vector lib

function onUpdate(diff)

end

function onDamageTaken(attacker, damage, type, source)

end

function onAutoAttack(target)

end

function onDealDamage(target, damage, type, source)

end

function onSpellCast(x, y, slot, target)

end

function onDie(killer)

end
