function finishCasting()
    addBuff("NasusR", 10.0, BUFFTYPE_TEMPORARY, owner)
	spellAnimation("Spell4_Full", owner)
end

function applyEffects()
	
end