using System;
 using System.Collections.Generic;
 using System.Linq;
 using System.Text;
 using System.Threading.Tasks;
 using System.Numerics;
 using LeagueSandbox.GameServer.Logic.GameObjects;
 using LeagueSandbox.GameServer.Logic.API;

 namespace Jax
 {
     public class E
     {
         public static void onStartCasting(Champion owner, Spell spell, Unit target)
         {

        
        
         }
         public static void onFinishCasting(Champion owner, Spell spell, Unit target)
         {

        
        
         }
         public static void applyEffects(Champion owner, Unit target, Spell spell, Projectile projectile)
         {

        
        
         }
         public static void onUpdate(double diff) {
       
        
          
         }
     }
 }