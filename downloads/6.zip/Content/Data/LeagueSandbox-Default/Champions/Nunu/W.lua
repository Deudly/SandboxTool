function finishCasting()
    local speedIncrease = 7 + spellLevel
    
    addBuff("BloodBoil", 12.0, owner)
end

function applyEffects()
end
