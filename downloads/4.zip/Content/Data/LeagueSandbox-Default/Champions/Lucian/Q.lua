Vector2 = require 'Vector2' -- include 2d vector lib 

function onFinishCasting()

	-- THIS IS A LASER SPELL TYPE BUT THE API DOESNT HAVE LASERS
	
	-- SO THIS SPELL CANNOT BE CREATED BY THE MOMENT

end
function applyEffects()

end
