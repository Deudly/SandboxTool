function onUpdate(diff)
	
end

function onDamageTaken(attacker, damage, type, source)
	
end

function onAutoAttack(target)

end

function onDealDamage(target, damage, damageType, source)
	
end

function onSpellCast(x, y, slot, target)
    
end

function onDie(killer)

end
