function finishCasting()
    addBuff("NasusR", 10.0, BUFFTYPE_TEMPORARY, getOwner())
	spellAnimation("Spell4_Full", getOwner())
end

function applyEffects()
	
end