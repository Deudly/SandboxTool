
function onAddBuff()
    modifyStats(apFlat, 300)
    modifyStats(size, 1.5)
    modifyStats(maxHp, 3000)
    modifyStats(moveSpeed, 700)
end

function onUpdate(diff)
	
end

function onBuffEnd()

end