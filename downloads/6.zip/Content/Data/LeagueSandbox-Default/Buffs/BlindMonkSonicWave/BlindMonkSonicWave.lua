function onAddBuff()
    
end

function onUpdate(diff)
    
end

function onBuffEnd()
    
end