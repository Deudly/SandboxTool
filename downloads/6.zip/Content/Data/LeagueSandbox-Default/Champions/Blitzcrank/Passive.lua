function onUpdate(diff)
end

function onDamageTaken(attacker, damage, dmgType, source)
end

function onAutoAttack(us, target)
end