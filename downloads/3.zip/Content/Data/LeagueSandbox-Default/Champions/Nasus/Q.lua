function finishCasting()
    addBuff("SiphoningStrike", 10.0, 1, getOwner(), getOwner())
    addBuff("NasusQStacks", 10.0, 1, getOwner(), getOwner())
end

function applyEffects()
end
