Vector2 = require 'Vector2' -- include 2d vector lib

function onStartCasting()

end

function onFinishCasting()

end

function applyEffects()

end

function onUpdate(diff)

end