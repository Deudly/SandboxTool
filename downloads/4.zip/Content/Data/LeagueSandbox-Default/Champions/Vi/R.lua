Vector2 = require 'Vector2' -- include 2d vector lib 

function onFinishCasting()
    dashToUnit(owner, castTarget, 800, false, "Spell4_run", 0, 99999)
end

function applyEffects()
end
