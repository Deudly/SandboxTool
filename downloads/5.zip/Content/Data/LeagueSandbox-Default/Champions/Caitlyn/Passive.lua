function onUpdate(diff)
end

function onDamageTaken(attacker, damage, dmgType, source)
end

function onAutoAttack(target)
end

function onDealDamage(target, damage, damageType, source)
end
