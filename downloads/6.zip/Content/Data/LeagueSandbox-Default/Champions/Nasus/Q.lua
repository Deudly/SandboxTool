function finishCasting()
    addBuff("SiphoningStrike", 10.0, 1, owner, owner)
    addBuff("NasusQStacks", 10.0, 1, owner, owner)
end

function applyEffects()
end
