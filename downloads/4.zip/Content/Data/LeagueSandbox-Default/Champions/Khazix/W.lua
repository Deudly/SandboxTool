Vector2 = require 'Vector2' -- include 2d vector lib 

function onFinishCasting()
end
function applyEffects()
end
