function onUpdate(diff)
end

function onDamageTaken(attacker, damage, dmgType, source)
end

function onDealDamage(target, damage, damageType, source)
end